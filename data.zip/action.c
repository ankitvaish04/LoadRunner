Action()
{

	web_set_sockets_option("SSL_VERSION", "2&3");

	web_add_cookie("SRCHD=AF=IE8SSC; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUID=V=2&GUID=6841182AF3094A41AF89F9F0AD81DFB4&dmnchg=1; DOMAIN=www.bing.com");

	web_add_cookie("SRCHUSR=DOB=20180604&T=1528097597000; DOMAIN=www.bing.com");

	web_add_cookie("_EDGE_V=1; DOMAIN=www.bing.com");

	web_add_cookie("MUID=0A41B0DF0B8066271B47BCDB0A2C67E0; DOMAIN=www.bing.com");

	web_add_cookie("_UR=D=0; DOMAIN=www.bing.com");

	web_add_cookie("SRCHHPGUSR=CW=1903&CH=995&DPR=1&UTC=330&WTS=63663694522; DOMAIN=www.bing.com");

	web_add_cookie("BFBN=gRDZeuuIiiWNKLR5NIdMOeKkfs2w62GvuzF7f2qGmsU3Sw; DOMAIN=www.bing.com");

	web_add_cookie("MUIDB=0A41B0DF0B8066271B47BCDB0A2C67E0; DOMAIN=www.bing.com");

	web_add_auto_header("DNT", 
		"1");

	web_add_auto_header("UA-CPU", 
		"AMD64");

	web_url("favicon.ico", 
		"URL=https://www.bing.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=", 
		"Snapshot=t1.inf", 
		LAST);

	web_url("favicon.ico_2", 
		"URL=https://www.bing.com/favicon.ico", 
		"Resource=1", 
		"RecContentType=image/x-icon", 
		"Referer=", 
		"Snapshot=t2.inf", 
		LAST);

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=928AF72263154E918BC134AC16FD9D60&dmnchg=1; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180115; DOMAIN=iecvlist.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=r20swj13mr.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=928AF72263154E918BC134AC16FD9D60&dmnchg=1; DOMAIN=r20swj13mr.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180115; DOMAIN=r20swj13mr.microsoft.com");

	web_add_cookie("SRCHD=AF=NOFORM; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUID=V=2&GUID=928AF72263154E918BC134AC16FD9D60&dmnchg=1; DOMAIN=ieonline.microsoft.com");

	web_add_cookie("SRCHUSR=DOB=20180115; DOMAIN=ieonline.microsoft.com");

	lr_think_time(6);

	web_url("iecompatviewlist.xml", 
		"URL=https://iecvlist.microsoft.com/IE11/1479242656000/iecompatviewlist.xml", 
		"Resource=0", 
		"RecContentType=text/xml", 
		"Referer=", 
		"Snapshot=t3.inf", 
		"Mode=HTML", 
		EXTRARES, 
		"Url=https://r20swj13mr.microsoft.com/ieblocklist/v1/urlblockindex.bin", "Referer=", ENDITEM, 
		"Url=https://ieonline.microsoft.com/iedomainsuggestions/ie11/suggestions.en-IN", "Referer=", ENDITEM, 
		LAST);

	return 0;
}